from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil
path = "irfiles/"
direct = os.listdir(path)

info =[]
for files in direct:
    filename = os.path.join(path, files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        text = open(filename,'r').read().strip().split()
        print text
        info.append(text)

destination = open('inv_index','wb')
for files in direct:
    filename = os.path.join(path,files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        shutil.copyfileobj(open(filename,'rb'),destination)
destination.close()            

