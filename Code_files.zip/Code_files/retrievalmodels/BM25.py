from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil

path = "irfiles/"
direct = os.listdir(path)
terminfo = []
termdict = {}
for files in direct:
    filename = os.path.join(path,files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        if len(terminfo) == 0:
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(f.tell())
            f.read()
            terminfo.append(f.tell())
            f.close()
        else:
            
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(terminfo[-2]+terminfo[-3])
            f.read()
            terminfo.append(f.tell())
            f.close()

#i is name of file, i+1 is its offset in index and i+2 length to read from offset            
i = 0        
while i < len(terminfo):
    termdict.update({terminfo[i]:[terminfo[i+1],terminfo[i+2]]})
    i = i+3
    
#-------------------------------

q2=['irfiles/planar', 'irfiles/convex', 'irfiles/hull']


#
loc = []
for each in q2:
    loc.append(termdict[each])

inv_terms =[] 
coll =[]
N = 3204
avgdoclen = 40.475031211

for locations in loc:
    f = open('inv_index','r')
    f.seek(locations[0],0)
    coll = f.read(locations[1]).split()
    inv_terms.append(coll)

#doument frequency calculation    
def docf(l):
    doc_f = len(l)/3
    return doc_f

def bm25(tf,doclen,df):
    t1 = math.log((N-df+0.5)/(df+0.5))
    K = 1.2 *(0.25 +(0.75*(doclen/avgdoclen)))
    t2 = ((1.2 + 1)*tf)/(K+tf)
    t3 = (100+1)/(100+1)
    res = (t1 * t2 * t3)
    return res

scores = []
for each in inv_terms:
    df = docf(each)
    s = 0
    while s<len(each):
        score = bm25(float(each[s+1]),float(each[s+2]),df)
        scores.append([int(each[s]),score])
        s = s+3

mydict ={}
for firstvalue, secondvalue in scores:
    oldvalue = mydict.get(firstvalue, 0)
    newvalue = oldvalue + secondvalue
    mydict[firstvalue] = newvalue    


dict_items =mydict.items()
dict_items.sort(lambda f,s: cmp(f[1],s[1]))
cnt = 1
for keys, values in reversed(dict_items):
    if cnt<=1000:
        print '2', 'Q0','CACM-'+str(keys), cnt, values, 'Exp'   
    cnt = cnt+1
