from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil
from collections import OrderedDict
from itertools import groupby
import collections
import itertools, operator
#Program for Okapi tf

path = "irfiles/"
direct = os.listdir(path)
terminfo = []
termdict = {}
for files in direct:
    filename = os.path.join(path,files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        if len(terminfo) == 0:
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(f.tell())
            f.read()
            terminfo.append(f.tell())
            f.close()
        else:
            
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(terminfo[-2]+terminfo[-3])
            f.read()
            terminfo.append(f.tell())
            f.close()

#i is name of file, i+1 is its offset in index and i+2 length to read from offset            
i = 0        
while i < len(terminfo):
    termdict.update({terminfo[i]:[terminfo[i+1],terminfo[i+2]]})
    i = i+3
#//////////
q64= ['irfiles/list', 'irfiles/articl', 'irfiles/el1', 'irfiles/el1', 'irfiles/given', 'irfiles/el1', 'irfiles/dont', 'irfiles/rememb', 'irfiles/did', 'irfiles/it', 'irfiles/cornel']

loc = []
for each in q64:
    loc.append(termdict[each])

inv_terms =[]
coll =[]    
for locations in loc:
    f = open('inv_index','r')
    f.seek(locations[0],0)
    coll = f.read(locations[1]).split()
    inv_terms.append(coll)

avgdoclen = 40.475031211
avgqlen = 13.125
def query_okapi (docid, tf, doclen):
    querylen = len(q64)
    qokapi = tf/(tf + 0.5 + (1.5*querylen/avgqlen))
    return qokapi
 

def proc_oktf (docid, tf, doclen):
    oktf = tf / (tf + 0.5 + (1.5*doclen/avgdoclen))
    q = query_okapi(docid, tf, doclen)
    res = oktf * q 
    return res

scores = []
for each in inv_terms:
    s = 0
    while s <len(each):
        score = proc_oktf(int(each[s]),float(each[s+1]),float(each[s+2]))
        scores.append([int(each[s]),score])
        s = s+3
mydict ={}
for firstvalue, secondvalue in scores:
    oldvalue = mydict.get(firstvalue, 0)
    newvalue = oldvalue + secondvalue
    mydict[firstvalue] = newvalue
dict_items =mydict.items()
dict_items.sort(lambda f,s: cmp(f[1],s[1]))


cnt = 1
for keys, values in reversed(dict_items):
    if cnt<=1000:
        print '64', 'Q0','CACM-'+str(keys), cnt, values, 'Exp'   
    cnt = cnt+1
