from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil
#Total no.of unique terms
U = 9971
path = "irfiles/"
direct = os.listdir(path)
terminfo = []
termdict = {}
for files in direct:
    filename = os.path.join(path,files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        if len(terminfo) == 0:
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(f.tell())
            f.read()
            terminfo.append(f.tell())
            f.close()
        else:
            
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(terminfo[-2]+terminfo[-3])
            f.read()
            terminfo.append(f.tell())
            f.close()

#i is name of file, i+1 is its offset in index and i+2 length to read from offset            
i = 0        
while i < len(terminfo):
    termdict.update({terminfo[i]:[terminfo[i+1],terminfo[i+2]]})
    i = i+3

#---------------
q64= ['irfiles/list', 'irfiles/articl', 'irfiles/el1', 'irfiles/el1', 'irfiles/given', 'irfiles/el1', 'irfiles/dont', 'irfiles/rememb', 'irfiles/did', 'irfiles/it', 'irfiles/cornel']
#
def docl(docid,tf,doclen):
    l=(tf+1)/(doclen+U)
    return (docid,l,1,doclen)

loc = []
for each in q64:
    loc.append(termdict[each])

inv_terms =[]
coll =[]    
for locations in loc:
    f = open('inv_index','r')
    f.seek(locations[0],0)
    coll = f.read(locations[1]).split()
    inv_terms.append(coll)


scores = []
for each in inv_terms:
    s = 0
    while s<len(each):
        tupex = docl(each[s],float(each[s+1]),float(each[s+2]))
        scores.append(tupex)
        s = s+3
        
newdict = {}
for docid,l,num,doclen in scores:
    if docid not in newdict:
        newdict.update({docid:(docid,l,num,doclen)})
    else:
        newdict[docid] = (docid, l*newdict[docid][1], (1+newdict[docid][2]), doclen)

def smoothfact(doclen):
    sf =  1 /(doclen + U)
    return sf
        
for docid,score,cnt,doclen in newdict.values():
    check = len(q64)-cnt
    if check != 0:
        newdict[docid] = (docid, score*(math.pow(smoothfact(doclen), check)), cnt, doclen)

req ={}        
for each in newdict.values():
    req.update({each[0]:each[1]})

dict_items =req.items()
dict_items.sort(lambda f,s: cmp(f[1],s[1]))
       
       
cnt = 1
for keys, values in reversed(dict_items):
    if cnt<=1000:
        print '64', 'Q0','CACM-'+str(keys), cnt, values, 'Exp'   
    cnt = cnt+1
    