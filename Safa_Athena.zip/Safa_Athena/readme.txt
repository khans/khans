athena Block Coding Puzzle:

Running time: 3.623474 seconds
Machine: Macbook Pro, Intel Core i5, 64 bit, Processor: 2.3 GHz, Memory: 4GB
Language used: Python
Editor: Wing IDE version: 4.1.3-1 

Overview:
I did some research online including Stack Exchange and Career Cup. 
I found some versions in Java,Pearl and Javascript. Used information from Stack Exchange regarding
the recursion to calculate arrangements.

Note: I also ran this program on Cloud 9 IDE. It seems to take a little longer there. 

Summary of program:
In the beginning I created global variables width and
height and assigned them values 48 and 10 respectively.

The procedure single_row() takes the width and calculates possible 
rows with brick size, 3 and 4.5 using recursion

The procedure checksum() takes a list of bricks
calculates the sum of the bricks in the list excluding the last brick
For example if we have [3,3,4.5,4.5], it will return [3,6,10.5]

The procedure list_of_bricksums() simply creates a list of the rows returned by checksum()

The procedure compatibility_matrix() uses the return value of list_of_bricksums().
It cretes a dictionary in which the keys correspond to each possible row, and values correspond
to acceptable row above it.
For example a row with checksum[3 6 9] cannot be placed on top of [3 7.5] because it means 
the spaces will line up, which is invalid

The procedure total_combinations() returns a list in which each index
corresponds to a row and the value corresponds to acceptable row arrangements

Finally the sum over the list returned by total_combinations is the total number of arrangements.

The answer for arrangements of 48*10 panel is 806844323190414

Please Note: In the pdf file description it says the width should 
be a multiple of 0.5, I think it should be 1.5

References: http://stackoverflow.com/
			http://www.careercup.com/
			http://www.ghettofix.com/puzzle.html
			http://www.overclock.net/

