#Athena Block Coding Puzzle
#To find the total number of ways to build a 48*10
import time
start = time.clock()

width=48
height=10

#Procedure uses recursion to find all possible rows for single rows of given width
def single_row(w):
            if w%1.5==0:    # The width has to be divisible by 1.5 else the blocks cannot be assembled
                        if w in range(3):
                                    return []
                        if w == 3:
                                    return [[3]]
                        if w == 4.5:
                                    return [[4.5]]
                        if w == 6:
                                    return [[3,3]]
            
                        else:
                                    return[(row+[3]) for row in single_row(w-3)]+ \
                                           [(row+[4.5]) for row in single_row(w-4.5)]
            else:
                        return []

#Number of combinationsfor width as 48 are 3329

#The following Procedure takes a single row and calculates the sum 
#ofconsecutive numbers excluding the last number
def checksum(single_row):
            bricksums=set()
            current = 0
            for i in range(0,len(single_row)-1):
                        bricksums.add(current+single_row[i])
                        current=current+single_row[i]
            return bricksums
#for ex: if row is [3,3,3] then it returns [3,6]


# The following Procedure uses checksum and applies to all rows 
def list_of_bricksums(rows):            
            brick_sums = []
            for each in rows:
                        brick_sums.append(checksum(each))
            return brick_sums

# Following Procedure creates a dictionary 
#This dictionary has keys corresponding to the rows calculated by single_row
#The value of the keys represent the acceptable top row
def compatibility_matrix(brick_sums):
            comp_matrix={}
            n=len(brick_sums)
            for i in range(n):
                        comp_matrix.update({i:[j for j in range(n) if brick_sums[j].isdisjoint(brick_sums[i])]})
            return comp_matrix


#Following Procedure gives a list of counts for each row's acceptable combinations
def total_combinations(compatibility_matrix,w,h):
            rows= single_row(w)
            num_of_rows=len(rows)
            combs= [1 for x in range(num_of_rows)]
            for x in range(1,h):            
                        combs=[sum(combs[i] for i in compatibility_matrix[j]) for j in range(num_of_rows)]
            return combs


s=single_row(width) # Possible rows
eachbrick_sumlist=list_of_bricksums(s) 
comp_matrix=compatibility_matrix(eachbrick_sumlist) # compatibility
totalcombinations=total_combinations(comp_matrix,width,height)

# The sum is the total number of ways to arrange 48*10 block panel
print sum(totalcombinations)
end = time.clock()
#print 'Time taken is',(end-start), 'seconds' #Time taken is 3.628457 seconds