from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil

#number of total unique terms
U = 9971
#irfiles is the folder
path = "irfiles/"
direct = os.listdir(path)
terminfo = []
termdict = {}
for files in direct:
    filename = os.path.join(path,files)
    if filename == 'irfiles/.DS_Store':
        continue
    else:
        if len(terminfo) == 0:
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(f.tell())
            f.read()
            terminfo.append(f.tell())
            f.close()
        else:
            
            f = open(filename,'r')
            terminfo.append(filename)
            terminfo.append(terminfo[-2]+terminfo[-3])
            f.read()
            terminfo.append(f.tell())
            f.close()

#i is name of file, i+1 is its offset in index and i+2 length to read from offset            
i = 0        
while i < len(terminfo):
    termdict.update({terminfo[i]:[terminfo[i+1],terminfo[i+2]]})
    i = i+3
#---------------------

q=[['irfiles/articl', 'irfiles/exist', 'irfiles/deal', 'irfiles/tss', 'irfiles/time', 'irfiles/share', 'irfiles/system', 'irfiles/oper', 'irfiles/system', 'irfiles/ibm', 'irfiles/comput'], ['irfiles/interest', 'irfiles/articl', 'irfiles/written', 'irfiles/priev', 'irfiles/pooch', 'irfiles/priev', 'irfiles/pooch'], ['irfiles/intermedi', 'irfiles/languag', 'irfiles/construct', 'irfiles/compil'], ['irfiles/interest', 'irfiles/mechan', 'irfiles/commun', 'irfiles/disjoint', 'irfiles/process', 'irfiles/possibl', 'irfiles/exclus', 'irfiles/distribut', 'irfiles/environ', 'irfiles/descript', 'irfiles/complet', 'irfiles/mechan', 'irfiles/implement', 'irfiles/oppos', 'irfiles/theoret', 'irfiles/work', 'irfiles/abstract', 'irfiles/problem', 'irfiles/remot', 'irfiles/procedur', 'irfiles/call', 'irfiles/messagpass', 'irfiles/exampl', 'irfiles/interest'], ['irfiles/id', 'irfiles/paper', 'irfiles/design', 'irfiles/implement', 'irfiles/edit', 'irfiles/interfac', 'irfiles/command', 'irfiles/interpret', 'irfiles/etc', 'irfiles/essenti', 'irfiles/issu', 'irfiles/human', 'irfiles/interfac', 'irfiles/design', 'irfiles/view', 'irfiles/improv', 'irfiles/user', 'irfiles/effici', 'irfiles/effect', 'irfiles/satisfact'], ['irfiles/interest', 'irfiles/articl', 'irfiles/robot', 'irfiles/motion', 'irfiles/plan', 'irfiles/particularli', 'irfiles/geometr', 'irfiles/combinatori', 'irfiles/aspect', 'irfiles/interest', 'irfiles/dynam', 'irfiles/arm', 'irfiles/motion'], ['irfiles/interest', 'irfiles/distribut', 'irfiles/algorithm', 'irfiles/concurr', 'irfiles/program', 'irfiles/process', 'irfiles/commun', 'irfiles/synchron', 'irfiles/messag', 'irfiles/pass', 'irfiles/area', 'irfiles/particular', 'irfiles/interest', 'irfiles/techniqu', 'irfiles/understand', 'irfiles/correct', 'irfiles/algorithm'], ['irfiles/address', 'irfiles/scheme', 'irfiles/resourc', 'irfiles/network', 'irfiles/resourc', 'irfiles/address', 'irfiles/network', 'irfiles/oper', 'irfiles/system'], ['irfiles/secur', 'irfiles/consider', 'irfiles/local', 'irfiles/network', 'irfiles/network', 'irfiles/oper', 'irfiles/system', 'irfiles/distribut', 'irfiles/system'], ['irfiles/parallel', 'irfiles/languag', 'irfiles/languag', 'irfiles/parallel', 'irfiles/comput'], ['irfiles/setl', 'irfiles/high', 'irfiles/level', 'irfiles/languag'], ['irfiles/portabl', 'irfiles/oper', 'irfiles/system'], ['irfiles/code', 'irfiles/optim', 'irfiles/space', 'irfiles/effici'], ['irfiles/find', 'irfiles/discuss', 'irfiles/optim', 'irfiles/implement', 'irfiles/sort', 'irfiles/algorithm', 'irfiles/databas', 'irfiles/manag', 'irfiles/applic'], ['irfiles/find', 'irfiles/discuss', 'irfiles/horizont', 'irfiles/microcod', 'irfiles/optim', 'irfiles/special', 'irfiles/emphasi', 'irfiles/optim', 'irfiles/loop', 'irfiles/global', 'irfiles/optim'], ['irfiles/find', 'irfiles/descript', 'irfiles/file', 'irfiles/handl', 'irfiles/oper', 'irfiles/system', 'irfiles/base', 'irfiles/multipl', 'irfiles/process', 'irfiles/messag', 'irfiles/pass'], ['irfiles/optim', 'irfiles/intermedi', 'irfiles/machin', 'irfiles/code'], ['irfiles/languag', 'irfiles/compil', 'irfiles/parallel', 'irfiles/processor', 'irfiles/especi', 'irfiles/highli', 'irfiles/horizont', 'irfiles/microcod', 'irfiles/machin', 'irfiles/code', 'irfiles/compact'], ['irfiles/parallel', 'irfiles/algorithm'], ['irfiles/graph', 'irfiles/theoret', 'irfiles/algorithm', 'irfiles/applic', 'irfiles/spars', 'irfiles/matric'], ['irfiles/comput', 'irfiles/complex', 'irfiles/intract', 'irfiles/reduct', 'irfiles/algorithm', 'irfiles/effici'], ['irfiles/interest', 'irfiles/hiddenline', 'irfiles/hiddensurfac', 'irfiles/algorithm', 'irfiles/cylind', 'irfiles/toroid', 'irfiles/sphere', 'irfiles/cone', 'irfiles/special', 'irfiles/topic', 'irfiles/comput', 'irfiles/graphic'], ['irfiles/distribut', 'irfiles/comput', 'irfiles/structur', 'irfiles/algorithm'], ['irfiles/appli', 'irfiles/stochast', 'irfiles/process'], ['irfiles/perform', 'irfiles/evalu', 'irfiles/model', 'irfiles/comput', 'irfiles/system'], ['irfiles/concurr', 'irfiles/control', 'irfiles/mechan', 'irfiles/oper', 'irfiles/system'], ['irfiles/memori', 'irfiles/manag', 'irfiles/aspect', 'irfiles/oper', 'irfiles/system'], ['irfiles/inform', 'irfiles/packet', 'irfiles/network', 'irfiles/particular', 'irfiles/interest', 'irfiles/algorithm', 'irfiles/packet', 'irfiles/rout', 'irfiles/deal', 'irfiles/chang', 'irfiles/network', 'irfiles/interest', 'irfiles/hardwar', 'irfiles/network'], ['irfiles/numbertheoret', 'irfiles/algorithm', 'irfiles/especi', 'irfiles/involv', 'irfiles/prime', 'irfiles/number', 'irfiles/seri', 'irfiles/siev', 'irfiles/chines', 'irfiles/remaind', 'irfiles/theorem'], ['irfiles/articl', 'irfiles/text', 'irfiles/format', 'irfiles/system', 'irfiles/what', 'irfiles/get', 'irfiles/system', 'irfiles/exampl'], ['irfiles/id', 'irfiles/find', 'irfiles/articl', 'irfiles/describ', 'irfiles/singular', 'irfiles/valu', 'irfiles/decomposit', 'irfiles/digit', 'irfiles/imag', 'irfiles/process', 'irfiles/applic', 'irfiles/find', 'irfiles/approxim', 'irfiles/origin', 'irfiles/imag', 'irfiles/restor', 'irfiles/imag', 'irfiles/subject', 'irfiles/nois', 'irfiles/articl', 'irfiles/subject', 'irfiles/hc', 'irfiles/andrew', 'irfiles/cl', 'irfiles/patterson', 'irfiles/outer', 'irfiles/product', 'irfiles/expans', 'irfiles/us', 'irfiles/digit', 'irfiles/imag', 'irfiles/process', 'irfiles/american', 'irfiles/mathemat', 'irfiles/monthli', 'irfiles/82', 'irfiles/andrew', 'irfiles/hc', 'irfiles/patterson', 'irfiles/cl'], ['irfiles/id', 'irfiles/find', 'irfiles/articl', 'irfiles/describ', 'irfiles/graph', 'irfiles/algorithm', 'irfiles/base', 'irfiles/eigenvalu', 'irfiles/decomposit', 'irfiles/or', 'irfiles/singular', 'irfiles/valu', 'irfiles/decomposit', 'irfiles/matrix', 'irfiles/graph', 'irfiles/especi', 'irfiles/interest', 'irfiles/heurist', 'irfiles/algorithm', 'irfiles/graph', 'irfiles/color', 'irfiles/graph', 'irfiles/isomorph', 'irfiles/method'], ['irfiles/articl', 'irfiles/sensit', 'irfiles/eigenvalu', 'irfiles/decomposit', 'irfiles/real', 'irfiles/matric', 'irfiles/particular', 'irfiles/zeroon', 'irfiles/matric', 'irfiles/especi', 'irfiles/interest', 'irfiles/separ', 'irfiles/correspond', 'irfiles/distinct', 'irfiles/eigenvalu', 'irfiles/articl', 'irfiles/subject', 'irfiles/davi', 'irfiles/wm', 'irfiles/kahn', 'irfiles/the', 'irfiles/rotat', 'irfiles/eigenvector', 'irfiles/permut', 'irfiles/numer', 'irfiles/analysi', 'irfiles/no', 'irfiles/1970', 'irfiles/gw', 'irfiles/stewart', 'irfiles/error', 'irfiles/bound', 'irfiles/approxim', 'irfiles/invari', 'irfiles/close', 'irfiles/linear', 'irfiles/oper', 'irfiles/numer', 'irfiles/analysi', 'irfiles/no', 'irfiles/1971', 'irfiles/davi', 'irfiles/kahn', 'irfiles/wm', 'irfiles/stewart', 'irfiles/gw'], ['irfiles/current', 'irfiles/interest', 'irfiles/isol', 'irfiles/root', 'irfiles/polynomi', 'irfiles/old', 'irfiles/articl', 'irfiles/acm', 'irfiles/find', 'irfiles/recent', 'irfiles/materi'], ['irfiles/probabilist', 'irfiles/algorithm', 'irfiles/especi', 'irfiles/deal', 'irfiles/algebra', 'irfiles/symbol', 'irfiles/manipul', 'irfiles/exampl', 'irfiles/probabilist', 'irfiles/algorithm', 'irfiles/finit', 'irfiles/field', 'irfiles/probabilist', 'irfiles/test', 'irfiles/polynomi', 'irfiles/ident'], ['irfiles/fast', 'irfiles/algorithm', 'irfiles/contextfree', 'irfiles/languag', 'irfiles/recognit', 'irfiles/pars'], ['irfiles/articl', 'irfiles/describ', 'irfiles/relationship', 'irfiles/data', 'irfiles/type', 'irfiles/concurr', 'irfiles/eg', 'irfiles/type', 'irfiles/process', 'irfiles/synchron', 'irfiles/attempt', 'irfiles/two', 'irfiles/process', 'irfiles/type', 'irfiles/correct', 'irfiles/messagpass', 'irfiles/system', 'irfiles/notion', 'irfiles/type', 'irfiles/wai', 'irfiles/check', 'irfiles/sender', 'irfiles/messag', 'irfiles/receiv', 'irfiles/treat', 'irfiles/bit', 'irfiles/stream', 'irfiles/particular', 'irfiles/type'], ['irfiles/type', 'irfiles/modul', 'irfiles/dont', 'irfiles/entir', 'irfiles/literatur', 'irfiles/abstract', 'irfiles/data', 'irfiles/type', 'irfiles/here', 'irfiles/sure', 'irfiles/phrase', 'irfiles/avoid', 'irfiles/it', 'irfiles/interest', 'irfiles/question', 'irfiles/check', 'irfiles/modul', 'irfiles/match', 'irfiles/context', 'irfiles/us'], ['irfiles/type', 'irfiles/compat', 'irfiles/mean', 'irfiles/languag', 'irfiles/allow', 'irfiles/programm', 'irfiles/defin', 'irfiles/type', 'irfiles/restrict', 'irfiles/extens', 'irfiles/languag', 'irfiles/allow', 'irfiles/definit', 'irfiles/abstract', 'irfiles/data', 'irfiles/type', 'irfiles/programmsuppli', 'irfiles/definit', 'irfiles/oper'], ['irfiles/list', 'irfiles/articl', 'irfiles/deal', 'irfiles/data', 'irfiles/type', 'irfiles/follow', 'irfiles/languag', 'irfiles/pascal', 'irfiles/clu', 'irfiles/alphard', 'irfiles/russel', 'irfiles/ada', 'irfiles/algol', 'irfiles/68', 'irfiles/el1', 'irfiles/list', 'irfiles/languag', 'irfiles/referenc', 'irfiles/frequent', 'irfiles/paper', 'irfiles/languag', 'irfiles/eg', 'irfiles/catch', 'irfiles/languag', 'irfiles/interest', 'irfiles/type', 'irfiles/structur', 'irfiles/miss'], ['irfiles/theori', 'irfiles/distribut', 'irfiles/system', 'irfiles/databas', 'irfiles/special', 'irfiles/interest', 'irfiles/reliabl', 'irfiles/distribut', 'irfiles/system', 'irfiles/atom', 'irfiles/distribut', 'irfiles/transact', 'irfiles/synchron', 'irfiles/algorithm', 'irfiles/resourc', 'irfiles/alloc', 'irfiles/lower', 'irfiles/bound', 'irfiles/model', 'irfiles/asynchron', 'irfiles/parallel', 'irfiles/system', 'irfiles/theori', 'irfiles/commun', 'irfiles/process', 'irfiles/protocol'], ['irfiles/comput', 'irfiles/perform', 'irfiles/evalu', 'irfiles/techniqu', 'irfiles/pattern', 'irfiles/recognit', 'irfiles/cluster'], ['irfiles/analysi', 'irfiles/percept', 'irfiles/shape', 'irfiles/human', 'irfiles/comput', 'irfiles/shape', 'irfiles/descript', 'irfiles/shape', 'irfiles/recognit', 'irfiles/comput', 'irfiles/twodimension', 'irfiles/shape', 'irfiles/measur', 'irfiles/circular', 'irfiles/shape', 'irfiles/match'], ['irfiles/textur', 'irfiles/analysi', 'irfiles/comput', 'irfiles/digit', 'irfiles/textur', 'irfiles/analysi', 'irfiles/textur', 'irfiles/synthesi', 'irfiles/percept', 'irfiles/textur'], ['irfiles/oper', 'irfiles/research', 'irfiles/model', 'irfiles/optim', 'irfiles/inform', 'irfiles/system', 'irfiles/perform', 'irfiles/includ', 'irfiles/fine', 'irfiles/tune', 'irfiles/decis', 'irfiles/secondari', 'irfiles/index', 'irfiles/select', 'irfiles/file', 'irfiles/reorgan', 'irfiles/distribut', 'irfiles/databas'], ['irfiles/applic', 'irfiles/fuzzi', 'irfiles/subset', 'irfiles/theori', 'irfiles/cluster', 'irfiles/inform', 'irfiles/retriev', 'irfiles/problem', 'irfiles/includ', 'irfiles/perform', 'irfiles/evalu', 'irfiles/automat', 'irfiles/index', 'irfiles/consider'], ['irfiles/decis', 'irfiles/model', 'irfiles/optim', 'irfiles/inform', 'irfiles/retriev', 'irfiles/system', 'irfiles/perform', 'irfiles/includ', 'irfiles/stop', 'irfiles/rule', 'irfiles/determin', 'irfiles/user', 'irfiles/scan', 'irfiles/output', 'irfiles/retriev', 'irfiles/search'], ['irfiles/comput', 'irfiles/scienc', 'irfiles/principl', 'irfiles/eg', 'irfiles/data', 'irfiles/structur', 'irfiles/numer', 'irfiles/method', 'irfiles/gener', 'irfiles/optim', 'irfiles/eg', 'irfiles/linear', 'irfiles/program', 'irfiles/algorithm', 'irfiles/includ', 'irfiles/issu', 'irfiles/russian', 'irfiles/ellipsoid', 'irfiles/algorithm', 'irfiles/complex', 'irfiles/algorithm'], ['irfiles/role', 'irfiles/inform', 'irfiles/retriev', 'irfiles/knowledg', 'irfiles/base', 'irfiles/system', 'irfiles/ie', 'irfiles/expert', 'irfiles/system'], ['irfiles/parallel', 'irfiles/processor', 'irfiles/inform', 'irfiles/retriev'], ['irfiles/parallel', 'irfiles/processor', 'irfiles/page', 'irfiles/algorithm'], ['irfiles/model', 'irfiles/simul', 'irfiles/ecosystem'], ['irfiles/mathemat', 'irfiles/induct', 'irfiles/group', 'irfiles/theori', 'irfiles/integ', 'irfiles/modulo', 'irfiles/probabl', 'irfiles/binomi', 'irfiles/coeffici', 'irfiles/binomi', 'irfiles/theorem', 'irfiles/homomorph', 'irfiles/transit', 'irfiles/relat', 'irfiles/relat', 'irfiles/matrix'], ['irfiles/semant', 'irfiles/program', 'irfiles/languag', 'irfiles/abstract', 'irfiles/specif', 'irfiles/data', 'irfiles/type', 'irfiles/denot', 'irfiles/semant', 'irfiles/proof', 'irfiles/correct', 'irfiles/hoar', 'irfiles/dijkstra'], ['irfiles/deal', 'irfiles/height', 'irfiles/regular', 'irfiles/languag', 'irfiles/regular', 'irfiles/express', 'irfiles/regular', 'irfiles/event'], ['irfiles/articl', 'irfiles/relat', 'irfiles/algebra', 'irfiles/theori', 'irfiles/studi', 'irfiles/automata', 'irfiles/regular', 'irfiles/languag'], ['irfiles/abstract', 'irfiles/articl', 'irfiles/backu', 'irfiles/can', 'irfiles/program', 'irfiles/liber', 'irfiles/von', 'irfiles/neumann', 'irfiles/style', 'irfiles/function', 'irfiles/style', 'irfiles/algebra', 'irfiles/program', 'irfiles/cacm', 'irfiles/1978', 'irfiles/millo', 'irfiles/rj', 'irfiles/lipton', 'irfiles/aj', 'irfiles/perli', 'irfiles/letter', 'irfiles/acm', 'irfiles/cacm', 'irfiles/1979', 'irfiles/backu', 'irfiles/de', 'irfiles/millo', 'irfiles/ra', 'irfiles/lipton', 'irfiles/rj', 'irfiles/perli', 'irfiles/aj'], ['irfiles/algorithm', 'irfiles/statist', 'irfiles/packag', 'irfiles/regress', 'irfiles/least', 'irfiles/squar', 'irfiles/gener', 'irfiles/linear', 'irfiles/model', 'irfiles/system', 'irfiles/design', 'irfiles/capabl', 'irfiles/statist', 'irfiles/formula', 'irfiles/interest', 'irfiles/students', 'irfiles/test', 'irfiles/sign', 'irfiles/test', 'irfiles/multivari', 'irfiles/univari', 'irfiles/compon', 'irfiles/includ'], ['irfiles/dictionari', 'irfiles/construct', 'irfiles/access', 'irfiles/method', 'irfiles/fast', 'irfiles/retriev', 'irfiles/word', 'irfiles/lexic', 'irfiles/item', 'irfiles/relat', 'irfiles/inform', 'irfiles/hash', 'irfiles/index', 'irfiles/method', 'irfiles/usual', 'irfiles/appli', 'irfiles/english', 'irfiles/spell', 'irfiles/natur', 'irfiles/languag', 'irfiles/problem'], ['irfiles/hardwar', 'irfiles/softwar', 'irfiles/relat', 'irfiles/databas', 'irfiles/manag', 'irfiles/system', 'irfiles/databas', 'irfiles/packag', 'irfiles/back', 'irfiles/end', 'irfiles/comput', 'irfiles/special', 'irfiles/associ', 'irfiles/hardwar', 'irfiles/microcomput', 'irfiles/attach', 'irfiles/disk', 'irfiles/head', 'irfiles/thing', 'irfiles/relat', 'irfiles/network', 'irfiles/codasyl', 'irfiles/hierarch', 'irfiles/model', 'irfiles/system', 'irfiles/system', 'irfiles/total', 'irfiles/etc'], ['irfiles/inform', 'irfiles/retriev', 'irfiles/articl', 'irfiles/gerard', 'irfiles/salton', 'irfiles/cluster', 'irfiles/bibliograph', 'irfiles/coupl', 'irfiles/citat', 'irfiles/vector', 'irfiles/space', 'irfiles/model', 'irfiles/boolean', 'irfiles/search', 'irfiles/method', 'irfiles/invert', 'irfiles/file', 'irfiles/feedback', 'irfiles/etc', 'irfiles/salton'], ['irfiles/result', 'irfiles/relat', 'irfiles/parallel', 'irfiles/complex', 'irfiles/theori', 'irfiles/both', 'irfiles/uniform', 'irfiles/circuit'], ['irfiles/algorithm', 'irfiles/parallel', 'irfiles/comput', 'irfiles/especi', 'irfiles/comparison', 'irfiles/parallel', 'irfiles/sequenti', 'irfiles/algorithm'], ['irfiles/list', 'irfiles/articl', 'irfiles/el1', 'irfiles/el1', 'irfiles/given', 'irfiles/el1', 'irfiles/dont', 'irfiles/rememb', 'irfiles/did', 'irfiles/it', 'irfiles/cornel']]




#
#Simple procedure for ctf of a term
def ctf_term(l):
    c = 1
    ctf = 0
    while c<len(l):
        ctf = ctf+int(l[c])
        c = c+3
    return ctf

#//////
total_dlen =129682
#///////
def docl(docid,tf,doclen):
    l=(tf+1)/(doclen+U)
    return (docid,l,1,doclen)
#////Jelinek function
def jelinek(docid,tf,doclen,l):
    ctf = ctf_term(l)
    jel = (0.1*(tf/doclen))+(0.9*(ctf/total_dlen))
    return (docid,jel,1,ctf)
#///////////////////////


x = 1
for eachq in q:
    loc = []
    for each in eachq:
        loc.append(termdict[each])

    inv_terms =[]
    coll =[]    
    for locations in loc:
        f = open('inv_index','r')
        f.seek(locations[0],0)
        coll = f.read(locations[1]).split()
        inv_terms.append(coll)

    scores = []
    for each in inv_terms:
        s = 0
        while s<len(each):
            tupex = jelinek(each[s],float(each[s+1]),float(each[s+2]),each)
            scores.append(tupex)
            s = s+3
    
    newdict ={}

    for docid,score,count,ctf in scores:
        if docid not in newdict:
            ctflist = []
            ctflist.append(ctf)
            newdict.update({docid: (docid,score,count,ctflist)}) 
        else:
            newctf = newdict[docid][3]
            newctf.append(ctf)
            newdict.update({docid:(docid,score+newdict[docid][1], newdict[docid][2]+1, newctf)})
                         
        #ctf's list        
    ctfs = []
    for each in inv_terms:
        ctf1 = ctf_term(each)
        ctfs.append(ctf1)
        #Applying smoothing:
    for items in newdict:
        for c in ctfs:
            if c not in newdict[items][3]:
                if c>0:
                    diff = math.log(0.9 *(c/total_dlen))
                    newdict[items] = (newdict[items][0],newdict[items][1]+diff, newdict[items][2], newdict[items][3])
                

    req ={}        
    for each in newdict.values():
        req.update({each[0]:each[1]})
                
    dict_items =req.items()
    dict_items.sort(lambda f,s: cmp(f[1],s[1]))
                       
                       
    cnt = 1
    for keys, values in reversed(dict_items):
        if cnt<=1000:
            print x, 'Q0','CACM-'+str(keys), cnt, values, 'Exp'   
        cnt = cnt+1
    x = x+1