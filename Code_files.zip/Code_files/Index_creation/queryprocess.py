from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil
from collections import OrderedDict
from itertools import groupby
import collections
import itertools, operator


path = "irfiles/"
direct = os.listdir(path)

stemtext = open('stemmedquery.txt','r').read().split()
#print stemtext

#procedure to remove punctuation
def rem_p(l):
   newl=[]
   for items in l:
      newitem = items.translate(string.maketrans("",""), string.punctuation)
      newl.append(newitem)  
   return newl 
#procedure to remove alphabets and ""
def rem_a(l):
   notneeded = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','']
   fspace = [t for t in l if t.lower() not in notneeded]
   return fspace
def rem_num(l):
   numless = [t for t in l if t.lower() not in str(range(1,65))]
   return numless

#loop for finding the documents and collecting terms
i = 0
j = 1
spacelist =[]
while j<64:
   stemtext.remove('.i')
   start_pos = stemtext.index('.w')
   stop_pos = stemtext.index('.n')
   space = stemtext[start_pos+1:stop_pos]  
   space_new = rem_p(space)
   fspace = rem_num(rem_a(space_new))
   spacelist.append((fspace,j))
   if (j!= 64):
      newstart = stemtext.index('.i')    
      del stemtext[0:newstart]
   j = j+1
#print spacelist

# adding query 64 to the queries list:
spacelist.append(((rem_num(rem_a(rem_p(stemtext[1: ])))),64))

terminfo = []
termdict = {}
for files in direct:
   filename = os.path.join(path,files)
   if filename == 'irfiles/.DS_Store':
      continue
   else:
      if len(terminfo) == 0:
         f = open(filename,'r')
         terminfo.append(filename)
         terminfo.append(f.tell())
         f.read()
         terminfo.append(f.tell())
         f.close()
      else: 
         f = open(filename,'r')
         terminfo.append(filename)
         terminfo.append(terminfo[-2]+terminfo[-3])
         f.read()
         terminfo.append(f.tell())
         f.close()


#k is name of file, k+1 is its offset in index and k+2 length to read from offset            
k = 0        
while k < len(terminfo):
   termdict.update({terminfo[k]:[terminfo[k+1],terminfo[k+2]]})
   k = k+3
         
# procedure to remove the words that dont exist in the files         
def rem_words(l):
   nl =[]
   for words in l:
      if words in termdict.keys():
         nl.append(words)
   return nl


#Retrieving updated queries:
queries = []
nl = []
for items in spacelist:
   tempq =[]
   for each in items[0]:
      tempq.append('irfiles/'+each)
   nl = rem_words(tempq)
   queries.append((nl,items[1]))

qs = []  # list of list of loactions in inverted list  
for each in queries:
   calc =[]
   for qterms in each[0]:
      calc.append(termdict[qterms])
   qs.append(calc)



inv_list =[]
coll =[]
for loclists in qs:
   inv_terms =[] 
   for locations in loclists:
      f = open('inv_index','r')
      f.seek(locations[0],0)
      coll = f.read(locations[1]).split()
      inv_terms.append(coll)
   inv_list.append(inv_terms)

#total doclen
totaldoclen = 129682
#No.docs
N = 3204
#//////////////////
avgdoclen = 40.475031211

#Simple df for a term:
#doc_f represents df
def docf(l):
   doc_f = len(l)/3
   return doc_f

#Simple procedure for ctf of a term
def ctf_term(l):
   c = 1
   ctf = 0
   while c<len(l):
      ctf = ctf+int(l[c])
      c = c+3
   return ctf



 



  





