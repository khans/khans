#!/usr/bin python
from __future__ import division
import re, math



# read contents and compare with stopwords
textwords = open('docs.txt', 'r').read().split()
stopwords = open('stoplist.txt', 'r').read().split()

filteredtext = [t for t in textwords if t.lower() not in stopwords]
#checking the list in the cleantextfile
s = open('cleantext.txt','r').read()

i = 0
terms = []
while True:
    pos_start = s.find('.t',i)
    if pos_start == -1:
        break
    pos_stop = s.find('.b', pos_start + 1)
    space = s[pos_start+3: pos_stop]
    l1 = space.split("','")
    #Use of regualr expression to take only alphabetic items
    newl1 =[re.sub(r'[^A-Za-z0-9]+', ' ', x) for x in l1]
    
    for words in newl1:
        if type(words) == type(""):
            if words not in terms:
                terms.append(words)
        i = pos_stop
print terms

