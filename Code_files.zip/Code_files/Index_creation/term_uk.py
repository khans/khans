#!/usr/bin python
from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string

stemtext = open('stemmed.txt','r').read().split()
#print stemtext

#procedure to remove punctuation
def rem_p(l):
   newl=[]
   for items in l:
      newitem = items.translate(string.maketrans("",""), string.punctuation)
      newl.append(newitem)  
   return newl 
#procedure to remove alphabets and ""
def rem_a(l):
   notneeded = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','']
   fspace = [t for t in l if t.lower() not in notneeded]
   return fspace
def rem_num(l):
   numless = [t for t in l if t.lower() not in str(range(1,65))]
   return numless

   
#loop for finding the documents and collecting terms
i = 0
j = 1
spacelist =[]
while j<3205:
   stemtext.remove('.i')
   start_pos = stemtext.index('.t')
   stop_pos = stemtext.index('.n')
   space = stemtext[start_pos+1:stop_pos]  
   space_new = rem_p(space)
   fspace = rem_num(rem_a(space_new))
   spacelist.append((fspace,j))
   if (j!= 3204):
      newstart = stemtext.index('.i')    
      del stemtext[0:newstart]
   j = j+1
#print spacelist
    
#use a default dictionary to count the no. of words in and their frequency
# items[1] is the doc id, keys is the term and d[keys] is the term frequency in 
# that document, len(items[0]) is the doclen

termlist = []
for items in spacelist:
   d = defaultdict(int)
   for word in items[0]:
      d[word] += 1  
   for keys in d:      
      termlist.append((keys, str(items[1]),d[keys],len(items[0])))

# create file for every unique term and put the information in it using irfiles
seen = set()
for items in termlist:
   if items[0] in seen:
      if (items[0] == ''):
         filename = "irfiles"+"/"+"space_1234"
         with open(filename,"a") as myfile:
            myfile.writelines(items[1]+"\t"+str(items[2])+"\t"+str(items[3])+"\n")
            myfile.close()
      else:
         filename = "irfiles"+"/"+items[0]
         with open(filename,"a") as myfile:
            myfile.writelines(items[1]+"\t"+ str(items[2])+"\t"+str(items[3])+"\n")
            myfile.close()
   else:
      if (items[0] == ''):
         seen.add(items[0])
         filename = "irfiles"+"/"+"space_1234"
         FILE = open(filename,"w")
         FILE.writelines(items[1]+"\t"+ str(items[2])+"\t"+str(items[3])+"\n")
         FILE.close()    
      else:
         seen.add(items[0])
         filename = "irfiles"+"/"+items[0]
         FILE = open(filename,"w")
         FILE.writelines(items[1]+"\t"+ str(items[2])+"\t"+str(items[3])+"\n")
         FILE.close()