#!/usr/bin python
from __future__ import division
from itertools import groupby
from collections import defaultdict
import re, math
import string
import os
import shutil

# Program caulates the document magnitude and unique words in a document.
N = 3204
stemtext = open('stemmed.txt','r').read().split()
#print stemtext

#procedure to remove punctuation
def rem_p(l):
   newl=[]
   for items in l:
      newitem = items.translate(string.maketrans("",""), string.punctuation)
      newl.append(newitem)  
   return newl 
#procedure to remove alphabets and ""
def rem_a(l):
   notneeded = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','']
   fspace = [t for t in l if t.lower() not in notneeded]
   return fspace
def rem_num(l):
   numless = [t for t in l if t.lower() not in str(range(1,65))]
   return numless



#loop for finding the documents and collecting terms
i = 0
j = 1
spacelist =[]
while j<3205:
   stemtext.remove('.i')
   start_pos = stemtext.index('.t')
   stop_pos = stemtext.index('.n')
   space = stemtext[start_pos+1:stop_pos]  
   space_new = rem_p(space)
   fspace = rem_num(rem_a(space_new))
   spacelist.append((fspace,j))
   if (j!= 3204):
      newstart = stemtext.index('.i')    
      del stemtext[0:newstart]
   j = j+1
#print spacelist
 
docunique ={}
for wordlist,docid in spacelist:
   nwordlist = []
   for words in wordlist:
      if words not in nwordlist:
         nwordlist.append(words)      
   docunique.update({docid:len(nwordlist)})
   

docvectors={}

for wordlist,docid in spacelist:
   d = defaultdict(int)
   for words in wordlist:
      d[words] +=1
   #print d
   sqsum = 0
   for each in d:
      sqsum = math.pow(d[each],2) +sqsum
   docvectors[docid] = math.sqrt(sqsum)
#------------------------------------------

 